export default function Navbar() {
    return (
        <nav className="navbar">
            {/* <div className="logo"></div>
            <ul className="nav-links">
                <li><a href="#services"></a></li>
                <li><a href="#gallery"></a></li>
            </ul> */}
        </nav>
    );
}
