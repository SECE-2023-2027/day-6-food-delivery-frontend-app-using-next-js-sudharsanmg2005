export default function Services() {
    return (
        <section
            id="about"
            style={{
                padding: '4rem 2rem',
                backgroundColor: 'transparent',
                textAlign: 'center',
                fontFamily: 'Arial, sans-serif'
            }}
        >
            <h2 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#111827' }}>

            </h2>
            {/* <p style={{ fontSize: '1rem', maxWidth: '700px', margin: '0 auto', color: '#444' }}>
                At <strong>UDAY_FOOD'S</strong>, we believe that food is more than just fuel — it’s a way of bringing people together.
                Our mission is to serve delicious, hygienic, and freshly prepared meals that delight your taste buds and warm your heart.
                Whether you're craving spicy tandoori, cheesy pizza, or a classic Indian thali, we've got it all!
            </p> */}
        </section>
    );
}
