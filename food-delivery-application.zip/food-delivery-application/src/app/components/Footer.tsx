export default function Footer() {
    return (
        <footer className="footer">
            <p>&copy; 2025 Inspire Web. All rights reserved.</p>
        </footer>
    );
}
